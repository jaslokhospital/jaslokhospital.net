﻿using BusinessDataLayer;
using DotNetNuke.Entities.Modules;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DesktopModules_JaslokAdmin_ManageNews : PortalModuleBase
{
    public CommonFn objCommonFn = new CommonFn();
    public BusinessLogic objBusinessLogic = new BusinessLogic();
    public DataAccessLogic objDALogic = new DataAccessLogic();
    public DataAccessEntities objDAEntities = new DataAccessEntities();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindNews(objDAEntities);
            ViewState["Newsid"] = 0;
            ViewState["optype"] = "INSERT";
            //objDAEntities.NewId = (int)ViewState["Newsid"];
           
        }

    }
    protected void dgNews_ItemCommand(object source, DataGridCommandEventArgs e)
    {
        
            DataSet ds = new DataSet();
            ds = null;
            if (e.CommandName == "Update")
            {
                txtNewsTitle.Text = e.Item.Cells[1].Text;
              txtNewsDate.SelectedDate = System.DateTime.Parse(e.Item.Cells[2].Text);
               if (e.Item.Cells[3].Text == "true")
                {
                 chkActive.Checked = true;
                  }
                else
                {
                    chkActive.Checked = false;
                }
              int newsid = (int)dgNews.DataKeys[e.Item.ItemIndex];
                ds = (DataSet)objBusinessLogic.GetNewsDetails(objDAEntities);
                txtNewsContent.Content = ds.Tables[0].Rows[0]["NewsContent"].ToString();

                ViewState["Newsid"] = newsid;
                ViewState["optype"] = "UPDATE";
                 btnSubmit.Text = "Update";
         }
        else if (e.CommandName == "Delete")
        {
            objDAEntities.optype = "DELETE";
            int newsid = (int)dgNews.DataKeys[e.Item.ItemIndex];
            ViewState["Newsid"] = newsid;
            objDAEntities.NewId = newsid;

            objBusinessLogic.AddEditDeleteNews(objDAEntities);
            ViewState["optype"] = "DELETE";
            lblMessage.Visible = true;
            lblMessage.CssClass = "successlbl";
            lblMessage.Text = "Data deleted successfully!!!";
            ViewState["optype"] = "INSERT";
        }
        BindNews(objDAEntities);

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            objDAEntities.optype = ViewState["optype"].ToString();
            objDAEntities.NewId = (int)ViewState["Newsid"];
            objDAEntities.NewsTitle = txtNewsTitle.Text;
            objDAEntities.NewsDate = DateTime.Parse(txtNewsDate.SelectedDate.ToString());
            objDAEntities.NewsContent = txtNewsContent.Content.Replace("&nbsp;", "");
            objDAEntities.CreatedBy = "1";
            if (chkActive.Checked == true)
            {
                objDAEntities.NewsIsActive = true;
            }
            else
            {
                objDAEntities.NewsIsActive = false;
            }
            lblMessage.Visible = true;
            if (ViewState["optype"].ToString() == "INSERT")
            {
                objBusinessLogic.AddEditDeleteNews(objDAEntities);

                lblMessage.CssClass = "successlbl";
                lblMessage.Text = "Data saved successfully!!!";
            }
            else if (ViewState["optype"].ToString() == "UPDATE")
            {
                objDAEntities.optype = "UPDATE";
                objBusinessLogic.AddEditDeleteNews(objDAEntities);
                lblMessage.CssClass = "successlbl";
                lblMessage.Text = "Data update successfully!!!";
            }

            ViewState["optype"] = "INSERT";
            BindNews(objDAEntities);
            Clear();

            btnSubmit.Text = "Save";
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        lblMessage.Visible = false;
        chkActive.Checked = false;
    }
    public void Clear()
    {
        txtNewsTitle.Text = "";
        txtNewsDate.SelectedDate = null;
        txtNewsContent.Content = null;
        chkActive.Checked = false;
    }
    public void BindNews(DataAccessEntities Slist)
    {
        try
        {
            objDAEntities.NewId = 0;
            DataSet ds = new DataSet();
            ds = null;
            ds = (DataSet)objBusinessLogic.GetNewsDetails(objDAEntities);


            if (ds.Tables[0].Rows.Count == 0)
            {
                //Bind your grid here
                lblempty.Visible = true;
                dgNews.Visible = false;

            }
            else
            {
                lblempty.Visible = false;
                dgNews.Visible = true;
                dgNews.DataSource = ds;
                dgNews.DataBind();
            }
            
        }
        catch (Exception ex)
        {

        }
    }
    protected void dgNews_ItemDataBound(object sender, DataGridItemEventArgs e)   
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            if (e.Item.Cells[3].Text == "True")
            {
                e.Item.Cells[3].Text = "Yes";
            }
            else
            {
                e.Item.Cells[3].Text = "No";
            }
        }
    }
    protected void dgNews_PageIndexChanging(object source, DataGridPageChangedEventArgs e)
    {
        dgNews.CurrentPageIndex = e.NewPageIndex;
        this.BindNews(objDAEntities);
    }
}