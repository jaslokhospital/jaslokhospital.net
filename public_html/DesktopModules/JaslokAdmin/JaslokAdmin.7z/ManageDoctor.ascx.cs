﻿using BusinessDataLayer;
using DotNetNuke.Entities.Modules;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DesktopModules_JaslokAdmin_ManageDoctor : PortalModuleBase
{
    public CommonFn objCommonFn = new CommonFn();
    public BusinessLogic objBusinessLogic = new BusinessLogic();
    public DataAccessLogic objDALogic = new DataAccessLogic();
    public DataAccessEntities objDAEntities = new DataAccessEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDoctor(objDAEntities);
            ViewState["DoctorId"] = 0;
            ViewState["optype"] = "INSERT";
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (UploadImages.PostedFile.FileName != "")
            {
                listofuploadedfiles.Text = SaveImage();
                 objDAEntities.dImageUrl = listofuploadedfiles.Text;
            }
            else
            {
                objDAEntities.dImageUrl = hdnImagePath.Value.TrimStart('~');
            }

            DataSet ds = new DataSet();
            ds = null;
            objDAEntities.DoctorId = (int)ViewState["DoctorId"];
            objDAEntities.dName = txtName.Text;
            objDAEntities.dTitle = txtTitle.Text;
            objDAEntities.Designation = txtDesignation.Text;
            objDAEntities.Description = redoctor.Content;
            objDAEntities.Specialization = txtSpecialization.Text;
            objDAEntities.dMobileNo = txtMob.Text;
            objDAEntities.dPhno = txtPhn.Text;
            objDAEntities.dEmailId = txtEmail.Text;

           
            lblMessage.Visible = true;
            if (ViewState["optype"].ToString() == "INSERT")
            {
                ds = (DataSet)objBusinessLogic.SaveDoctor(objDAEntities);
                lblMessage.CssClass = "successlbl";
                lblMessage.Text = "Data save successfully!!!";
            }
            else if (ViewState["optype"].ToString() == "UPDATE")
            {
                objDAEntities.optype = "UPDATE";
                ds = (DataSet)objBusinessLogic.UpdateDeleteDoctor(objDAEntities);
                lblMessage.CssClass = "successlbl";
                lblMessage.Text = "Data update successfully!!!";
            }

            ViewState["optype"] = "INSERT";
            BindDoctor(objDAEntities);
            Clear();
            
        }
        catch (Exception ex)
        {

        }
    }
    public void BindDoctor(DataAccessEntities Slist)
    {
        try
        {

            DataSet ds = new DataSet();
            ds = null;
            objDAEntities.DoctorId = 0;
            ds = (DataSet)objBusinessLogic.GetDoctorDetails(objDAEntities);

            if (ds.Tables[0].Rows.Count == 0)
            {
              
                lblempty.Visible = true;
                dgDoctor.Visible = false;

            }
            else
            {
                lblempty.Visible = false;
                dgDoctor.Visible = true;
                dgDoctor.DataSource = ds;
                dgDoctor.DataBind();
            }      


        }
        catch (Exception ex)
        {
        }
    }
    protected void dgDoctor_ItemCommand(object source, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Update")
        {
            int DoctorId = (int)dgDoctor.DataKeys[e.Item.ItemIndex];
            objDAEntities.DoctorId = DoctorId;
            ViewState["DoctorId"] = DoctorId;
            ViewState["optype"] = "UPDATE";
            DataSet ds = new DataSet();
            ds = (DataSet)objBusinessLogic.GetDoctorDetails(objDAEntities);
            txtName.Text = ds.Tables[0].Rows[0]["Name"].ToString();
            txtMob.Text = ds.Tables[0].Rows[0]["MobileNo"].ToString();
            txtPhn.Text = ds.Tables[0].Rows[0]["PhoneNo"].ToString();
            txtEmail.Text = ds.Tables[0].Rows[0]["EmailId"].ToString();
            txtTitle.Text = ds.Tables[0].Rows[0]["Title"].ToString();
            txtDesignation.Text = ds.Tables[0].Rows[0]["Designation"].ToString();
            txtSpecialization.Text = ds.Tables[0].Rows[0]["Specialization"].ToString();
            redoctor.Content = ds.Tables[0].Rows[0]["Description"].ToString();
            hdnImagePath.Value = ds.Tables[0].Rows[0]["ImageUrl"].ToString();
            
        }
        else if (e.CommandName == "Delete")
        {
            DataSet ds = new DataSet();
            objDAEntities.optype = "DELETE";
            int DoctorId = (int)dgDoctor.DataKeys[e.Item.ItemIndex];
            objDAEntities.DoctorId = DoctorId;
            ds = (DataSet)objBusinessLogic.UpdateDeleteDoctor(objDAEntities);
            lblMessage.CssClass = "successlbl";
            lblMessage.Text = "Data deleted successfully!!!";
            ViewState["optype"] = "INSERT";

        }
        BindDoctor(objDAEntities);
    }
    public void Clear()
    {
        txtName.Text = "";
        txtDesignation.Text = "";
        redoctor.Content = "";
        txtSpecialization.Text = "";
        txtPhn.Text = "";
        txtMob.Text = "";
        txtEmail.Text = "";
        txtTitle.Text = "";
        listofuploadedfiles.Text = "";
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        lblMessage.Visible = false;
    }
    protected string SaveImage()
    {
        string strDBImagePath = string.Empty;
        try
        {
            string strServerPath = Server.MapPath(CommonFn.Image_Save_Path);
            string strSaveImagePath = string.Empty;
            string fileName = Path.GetFileName(UploadImages.PostedFile.FileName);
            String FileExtension = System.IO.Path.GetExtension(fileName);
            string FolderName = CommonFn.DoctorFolder;
            if ((FileExtension.ToLower() == ".jpg" || FileExtension.ToLower() == ".png" || FileExtension.ToLower() == ".jpeg" || FileExtension.ToLower() == ".tiff" || FileExtension.ToLower() == ".gif"))
            {
                if (!CommonFn.folderExists(strServerPath, FolderName))
                {
                    try
                    {
                        CommonFn.CreateFolder(strServerPath, FolderName);
                    }
                    catch { }
                }
                string strFileNameOnly = CommonFn.GetFileName(fileName);
                strSaveImagePath = strServerPath + FolderName + "\\" + strFileNameOnly;
                UploadImages.SaveAs(strSaveImagePath);
                strDBImagePath = CommonFn.DbSave + CommonFn.DbDoctorFolder;
                strDBImagePath = strDBImagePath + strFileNameOnly;
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Only Image file allowed!!!');", true);
            }
        }
        catch
        {
            //ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Only Image file allowed!!!');", true);
        }
        return strDBImagePath;
    }
    protected void dgDoctor_PageIndexChanging(object source, DataGridPageChangedEventArgs e)
    {
        dgDoctor.CurrentPageIndex = e.NewPageIndex;
        this.BindDoctor(objDAEntities);
    }
    //protected void dgDoctor_ItemDataBound(object sender, DataGridItemEventArgs e)
    //{
    //    if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
    //    {
    //        Image ImgDoctor = (Image)e.Item.FindControl("ImageUrl");

    //        ImgDoctor.ImageUrl = !string.IsNullOrEmpty(DataBinder.Eval(e.Item.ItemType, "ImageUrl").ToString()) ? DataBinder.Eval(e.Item.ItemType, "ImageUrl").ToString() : CommonFn.DefaultImagePath;

    //    }
    //}
}