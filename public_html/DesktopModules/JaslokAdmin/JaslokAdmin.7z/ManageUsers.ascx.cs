﻿using BusinessDataLayer;
using DotNetNuke.Entities.Modules;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DesktopModules_JaslokAdmin_ManageUsers : PortalModuleBase
{
    public CommonFn objCommonFn = new CommonFn();
    public BusinessLogic objBusinessLogic = new BusinessLogic();
    public DataAccessLogic objDALogic = new DataAccessLogic();
    public DataAccessEntities objDAEntities = new DataAccessEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindUserType();
            BindUsers(0);
            ViewState["UserId"] = 0;
            ViewState["optype"] = "INSERT";
            btnSubmit.Text = "Save";
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (UploadImages.PostedFile.FileName != "")
            {
                listofuploadedfiles.Text = SaveImage();
            }
            DataSet ds = new DataSet();
            ds = null;
            objDAEntities.UserId = (int)ViewState["UserId"];
            objDAEntities.UName = txtName.Text;
            objDAEntities.UTitle = txtTitle.Text;
            objDAEntities.UDesignation = txtDesignation.Text;
            objDAEntities.UDescription = reUser.Content;
            objDAEntities.UTypeId = Convert.ToInt32(ddlUserType.SelectedValue);
            objDAEntities.UContactNo = txtMob.Text;
            objDAEntities.UEmail = txtEmail.Text;
            objDAEntities.UIsActive = ckbIsActive.Checked;
            objDAEntities.UImageUrl = listofuploadedfiles.Text;
            lblMessage.Visible = true;
            if (ViewState["optype"].ToString() == "INSERT")
            {
                string msg = objBusinessLogic.SaveUser(objDAEntities);
                if (msg != "")
                {
                    lblMessage.CssClass = "errorlbl";
                    lblMessage.Text = "Email Id already exists!!!";
                }
                else
                {
                    lblMessage.CssClass = "successlbl";
                    lblMessage.Text = "Data Save successfully!!!";
                }
            }
            else if (ViewState["optype"].ToString() == "UPDATE")
            {
                objDAEntities.optype = "UPDATE";
                ds = (DataSet)objBusinessLogic.UpdateDeleteUser(objDAEntities);
                lblMessage.CssClass = "successlbl";
                lblMessage.Text = "Data Updated successfully!!!";
            }
            BindUsers(0);
            ViewState["optype"] = "INSERT";
            Clear();
            //}
            //else
            //{
            //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please select and upload  file!!!');", true);
            //}
        }
        catch (Exception ex)
        {

        }
    }
    public DataSet BindUsers(int id)
    {
        try
        {
            DataSet ds = new DataSet();
            ds = null;
            objDAEntities.UserId = id;
            ds = (DataSet)objBusinessLogic.GetUserDetails(objDAEntities);

            if (ds.Tables[0].Rows.Count == 0)
            {
                //Bind your grid here
                lblempty.Visible = true;
                dgUsers.Visible = false;

            }
            else
            {
                lblempty.Visible = false;
                dgUsers.Visible = true;
                dgUsers.DataSource = ds;
                dgUsers.DataBind();
            }
           
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void dgUsers_ItemCommand(object source, DataGridCommandEventArgs e)
    {
        objDAEntities.UserId = (int)dgUsers.DataKeys[e.Item.ItemIndex];
        ViewState["UserId"] = objDAEntities.UserId;
        if (e.CommandName == "Update")
        {
            DataSet ds = new DataSet();
            txtName.Text = e.Item.Cells[2].Text;
            if (ddlUserType.Items.FindByText(e.Item.Cells[3].Text) != null)
            {
                ddlUserType.ClearSelection();
                ddlUserType.Items.FindByText(e.Item.Cells[3].Text).Selected = true;
            }
            txtDesignation.Text = e.Item.Cells[4].Text.Replace("&nbsp;", ""); 
            txtTitle.Text = e.Item.Cells[5].Text;
            txtMob.Text = e.Item.Cells[6].Text;
            txtEmail.Text = e.Item.Cells[7].Text;
            if (e.Item.Cells[8].Text == "True")
            {
                ckbIsActive.Checked = true;
            }
            //reUser.Content = e.Item.Cells[9].Text;

            ds = (DataSet)objBusinessLogic.GetUserDetails(objDAEntities);

            //ds = BindUsersDescription(objDAEntities.UserId);
            listofuploadedfiles.Text = ds.Tables[0].Rows[0]["ImageUrl"].ToString();
            reUser.Content = ds.Tables[0].Rows[0]["Description"].ToString();

            //hdnImagePath.Value = listofuploadedfiles.Text;


            ViewState["optype"] = "UPDATE";
            btnSubmit.Text = "Update";
        }
        else if (e.CommandName == "Delete")
        {
            DataSet ds = new DataSet();
            objDAEntities.optype = "DELETE";
            objBusinessLogic.UpdateDeleteUser(objDAEntities);
            lblMessage.Visible = true;
            lblMessage.CssClass = "successlbl";
            lblMessage.Text = "Data deleted successfully!!!";
            ViewState["optype"] = "INSERT";

        }
        BindUsers(0);
    }
    public void Clear()
    {
        txtName.Text = "";
        txtDesignation.Text = "";
        reUser.Content = "";
        txtMob.Text = "";
        txtEmail.Text = "";
        txtTitle.Text = "";
        ckbIsActive.Checked = false;
        ddlUserType.ClearSelection();
        listofuploadedfiles.Text = "";
    }

    protected void BindUserType()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = null;
            ds = (DataSet)objBusinessLogic.GetUserType();

            ddlUserType.DataValueField = "UserTypeId";
            ddlUserType.DataTextField = "UserType";


            ddlUserType.DataSource = ds;
            ddlUserType.DataBind();
            ddlUserType.Items.Insert(0, new ListItem("-Select-", "0"));

        }
        catch
        {
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        lblMessage.Visible = false;
    }

    protected string SaveImage()
    {
        string strDBImagePath = string.Empty;
        try
        {
            if (UploadImages.PostedFile.ContentLength < 1035000)
            {
                string strServerPath = Server.MapPath(CommonFn.Image_Save_Path);
                string strSaveImagePath = string.Empty;
                string fileName = Path.GetFileName(UploadImages.PostedFile.FileName);

                string FileNameWEx = Path.GetFileNameWithoutExtension(fileName);

                FileNameWEx = objDAEntities.RemoveBadCharForFolder(FileNameWEx);

                String FileExtension = System.IO.Path.GetExtension(fileName);
                //listofuploadedfiles.Text = fileName;
                if ((FileExtension.ToLower() == ".jpg" || FileExtension.ToLower() == ".png" || FileExtension.ToLower() == ".jpeg" || FileExtension.ToLower() == ".tiff" || FileExtension.ToLower() == ".gif"))
                {

                    string FolderName = CommonFn.UserGalleryFolder;
                    if (!CommonFn.folderExists(strServerPath, FolderName))
                    {
                        try
                        {
                            CommonFn.CreateFolder(strServerPath, FolderName);
                        }
                        catch { }
                    }

                    string strFileNameOnly = CommonFn.GetFileName(fileName);
                    strSaveImagePath = strServerPath + FolderName + "\\" + strFileNameOnly + FileExtension;
                    UploadImages.SaveAs(strSaveImagePath);

                    strDBImagePath = CommonFn.DbSave + CommonFn.DbUserGalleryFolder;
                    strDBImagePath = strDBImagePath + strFileNameOnly;
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Images size is more than 1.035 mb!!!');", true);
            }
        }
        catch
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Something worng!!!');", true);
        }
        return strDBImagePath;
    }
    protected void dgUsers_PageIndexChanging(object source, DataGridPageChangedEventArgs e)
    {
        dgUsers.CurrentPageIndex = e.NewPageIndex;
        this.BindUsers(0);
    }
    //public void UploadFile(FileUpload UploadImages, string fileName, string type, string path)
    //{

    //    string Image_Save_Path = ConfigurationManager.AppSettings[type];
    //    String FileExtension = System.IO.Path.GetExtension(fileName);
    //    if (FileExtension.ToLower() == ".jpg" || FileExtension.ToLower() == ".png" || FileExtension.ToLower() == ".jpeg")
    //    {
    //        if (!System.IO.Directory.Exists(path + Image_Save_Path))
    //        {
    //            DirectoryInfo di = Directory.CreateDirectory(path + Image_Save_Path);
    //        }
    //        else
    //        {
    //            int count = 0;
    //            if (File.Exists(fileName))
    //            {
    //                fileName = fileName + "(" + count.ToString() + ").txt";
    //                count++;

    //            }
    //            DirectoryInfo di = Directory.CreateDirectory(path + Image_Save_Path);
    //            UploadImages.PostedFile.SaveAs(path + Image_Save_Path + "/" + fileName);
    //        }
    //    }
    //    else
    //    {
    //    }
    //}
}