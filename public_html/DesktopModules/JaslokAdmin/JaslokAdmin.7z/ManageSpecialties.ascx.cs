﻿using BusinessDataLayer;
using DotNetNuke.Entities.Modules;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DesktopModules_JaslokAdmin_ManageSpecialties : PortalModuleBase
{
    public CommonFn objCommonFn = new CommonFn();
    public BusinessLogic objBusinessLogic = new BusinessLogic();
    public DataAccessLogic objDALogic = new DataAccessLogic();
    public DataAccessEntities objDAEntities = new DataAccessEntities();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindSpeciltyCategory();
            BindSpecialty(0);
            ViewState["Specialtyid"] = 0;
            ViewState["optype"] = "INSERT";           
        }
        objDAEntities.SelectTabId = "";
    }
    protected void BindSpeciltyCategory()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = null;
            ds = (DataSet)objBusinessLogic.GetSpecialtyCategoryDetails();

            drpspecialCategory.DataValueField = "CategoryId";
            drpspecialCategory.DataTextField = "CategoryName";


            drpspecialCategory.DataSource = ds;
            drpspecialCategory.DataBind();
            drpspecialCategory.Items.Insert(0, new ListItem("-Select-", "0"));

        }
        catch
        {
        }
    }
    protected void dgSpecialty_ItemCommand(object source, DataGridCommandEventArgs e)
    {
        int Specialtyid = (int)dgSpecialty.DataKeys[e.Item.ItemIndex];
        ViewState["Specialtyid"] = Specialtyid;
        objDAEntities.SpecialtyId = Specialtyid;

        if (e.CommandName == "Update")
        {
            if (drpspecialCategory.Items.FindByText(e.Item.Cells[1].Text) != null)
            {
                drpspecialCategory.ClearSelection();
                drpspecialCategory.Items.FindByText(e.Item.Cells[1].Text).Selected = true;
            }           

            txtSpecialtyName.Text = e.Item.Cells[2].Text;
            

            
            DataSet ds = new DataSet();
            ds = null;
            ds = (DataSet)objBusinessLogic.GetSpecialtiesDescription(Specialtyid);
            listofuploadedfiles.Value = ds.Tables[0].Rows[0]["ImageUrl"].ToString();
            txtimageTitle.Text = ds.Tables[0].Rows[0]["ImageTitle"].ToString();
            txtImageAltTag.Text = ds.Tables[0].Rows[0]["ImageAlt"].ToString();
               
            txtSpecialtyDesc.Content = ds.Tables[0].Rows[0]["About"].ToString();
            txtFacilitiesServices.Content = ds.Tables[0].Rows[0]["Facilities"].ToString();

            ViewState["optype"] = "UPDATE";
            btnSubmit.Text = "Update";
        }
        else if (e.CommandName == "Delete")
        {
            objDAEntities.optype = "DELETE";
           objBusinessLogic.UpdateDeleteSpecialties(objDAEntities);
           lblMessage.Visible = true;
           lblMessage.CssClass = "successlbl";
           lblMessage.Text = "Data deleted successfully!!!";
            ViewState["optype"] = "INSERT";
        }
        BindSpecialty(0);
    }

    public void Clear()
    {
        drpspecialCategory.ClearSelection();
        txtImageAltTag.Text = "";
        txtimageTitle.Text = "";
        listofuploadedfiles.Value = "";
        txtSpecialtyName.Text = "";
        txtSpecialtyDesc.Content = "";
        txtFacilitiesServices.Content = "";
        btnSubmit.Text = "Save";
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        lblMessage.Visible = false;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (UploadImages.PostedFile.FileName != "")
            {
                listofuploadedfiles.Value = SaveImage();
            }
            DataSet ds = new DataSet();
            ds = null;
            objDAEntities.SpecialtyId = (int)ViewState["Specialtyid"];
            objDAEntities.CategoryId = Convert.ToInt32(drpspecialCategory.SelectedValue);
            objDAEntities.SpecialtyName = txtSpecialtyName.Text;
            objDAEntities.ImageUrl = listofuploadedfiles.Value;
            objDAEntities.PhotoTitle = txtimageTitle.Text;
            objDAEntities.AlternateText = txtImageAltTag.Text;
            objDAEntities.About = txtSpecialtyDesc.Content.Replace("&nbsp;", "");
            objDAEntities.Facilities = txtFacilitiesServices.Content.Replace("&nbsp;", "");
            
            lblMessage.Visible = true;
            if (ViewState["optype"].ToString() == "INSERT")
            {
                ds = (DataSet)objBusinessLogic.SaveSpecialties(objDAEntities);
               
                lblMessage.CssClass = "successlbl";
                lblMessage.Text = "Data saved successfully!!!";
            }
            else if (ViewState["optype"].ToString() == "UPDATE")
            {
                objDAEntities.optype = "UPDATE";
               objBusinessLogic.UpdateDeleteSpecialties(objDAEntities);
               lblMessage.CssClass = "successlbl";
               lblMessage.Text = "Data update successfully!!!";
            }

            ViewState["optype"] = "INSERT";
           BindSpecialty(0);
            Clear();
           
            btnSubmit.Text = "Save";
        }
        catch (Exception ex)
        {
           
        }
    }
    public void BindSpecialty(int Categoryid)
    {
        try
        {
            DataSet ds = new DataSet();
            ds = null;
            ds = (DataSet)objBusinessLogic.GetSpecialtiesDetails(Categoryid);

            if (ds.Tables[0].Rows.Count == 0)
            {
                //Bind your grid here
                lblempty.Visible = true;
                dgSpecialty.Visible = false;
            }
            else
            {
                lblempty.Visible = false;
                dgSpecialty.Visible = true;
                dgSpecialty.DataSource = ds;
                dgSpecialty.DataBind();
            }           
        }
        catch (Exception ex)
        {

        }
    }
    protected void drpspecialCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        int Cid =Convert.ToInt32(drpspecialCategory.SelectedValue);
        BindSpecialty(Cid);
    }
    protected void dgSpecialty_PageIndexChanging(object source, DataGridPageChangedEventArgs e)
    {
        dgSpecialty.CurrentPageIndex = e.NewPageIndex;
        this.BindSpecialty(0);
    }
    protected string SaveImage()
    {
        string strDBImagePath = string.Empty;
        try
        {
            if (UploadImages.PostedFile.ContentLength > 0)
            {
                string strServerPath = Server.MapPath(CommonFn.Image_Save_Path);
                string strSaveImagePath = string.Empty;
                string fileName = Path.GetFileName(UploadImages.PostedFile.FileName);

                string FileNameWEx = Path.GetFileNameWithoutExtension(fileName);

                FileNameWEx = objDAEntities.RemoveBadCharForFolder(FileNameWEx);

                String FileExtension = System.IO.Path.GetExtension(fileName);
                //listofuploadedfiles.Text = fileName;
                if ((FileExtension.ToLower() == ".jpg" || FileExtension.ToLower() == ".png" || FileExtension.ToLower() == ".jpeg" || FileExtension.ToLower() == ".tiff" || FileExtension.ToLower() == ".gif"))
                {

                    string FolderName = CommonFn.SpecialtiesFolder;
                    if (!CommonFn.folderExists(strServerPath, FolderName))
                    {
                        try
                        {
                            CommonFn.CreateFolder(strServerPath, FolderName);
                        }
                        catch { }
                    }

                    string strFileNameOnly = CommonFn.GetFileName(fileName);
                    strSaveImagePath = strServerPath + FolderName + "\\" + strFileNameOnly + FileExtension;
                    UploadImages.SaveAs(strSaveImagePath);

                    strDBImagePath = CommonFn.DbSave + CommonFn.DbSpecialtiesFolder;
                    strDBImagePath = strDBImagePath + strFileNameOnly;
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Images size is more than 1.03 mb=1035000!!!');", true);
            }
        }
        catch
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Something worng!!!');", true);
        }
        return strDBImagePath;
    }
}