﻿using BusinessDataLayer;
using DotNetNuke.Entities.Modules;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DotNetNuke.Modules.JaslokAdmin
{
    public partial class ManageCareerCategory : PortalModuleBase
    {
        public BusinessLogic objBusinessLogic = new BusinessLogic();
        public DataAccessLogic objDALogic = new DataAccessLogic();
        public DataAccessEntities objDAEntities = new DataAccessEntities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               BindPage();
                ViewState["FunctionId"] = 0;
                ViewState["optype"] = "INSERT";
            }
        }
         protected void dgCareer_ItemCommand(object source, DataGridCommandEventArgs e)
        {
            objDAEntities.FunctionId = (int)dgCareer.DataKeys[e.Item.ItemIndex];
            ViewState["FunctionId"] = objDAEntities.FunctionId;

            if (e.CommandName == "Update")
            {
                txtFunctionName.Text = e.Item.Cells[1].Text;
                if (e.Item.Cells[2].Text == "True")
                {
                    ckbIsActive.Checked = true;
                }              
                ViewState["optype"] = "UPDATE";
                btnSubmit.Text = "Update";
            }
            else if (e.CommandName == "Delete")
            {
                DataSet ds = new DataSet();
                objDAEntities.optype = "DELETE";
                objBusinessLogic.UpdateDeleteCareerCategory(objDAEntities);
                lblMessage.Visible = true;
                lblMessage.CssClass = "successlbl";
                lblMessage.Text = "Data deleted successfully!!!";
               ViewState["optype"] = "INSERT";
            }
            BindPage();
        }

        public void Clear()
        {
            txtFunctionName.Text = "";
            ckbIsActive.Checked = false;
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            lblMessage.Visible = false;
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                objDAEntities.FunctionId = (int)ViewState["FunctionId"];
                objDAEntities.FunctionName = txtFunctionName.Text;
                objDAEntities.UIsActive = ckbIsActive.Checked;
                lblMessage.Visible = true;
                if (ViewState["optype"].ToString() == "INSERT")
                {
                    string msg = objBusinessLogic.SaveCareerCategory(objDAEntities);
                    lblMessage.CssClass = "successlbl";
                    lblMessage.Text = "Data Save successfully!!!";
                }
                else if (ViewState["optype"].ToString() == "UPDATE")
                {
                    objDAEntities.optype = "UPDATE";
                    objBusinessLogic.UpdateDeleteCareerCategory(objDAEntities); 
                    lblMessage.CssClass = "successlbl";
                    lblMessage.Text = "Data Updated successfully!!!";
                }
                ViewState["optype"] = "INSERT";
               BindPage();
               Clear();
                //ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Data saved successfully!!!');", true);
               btnSubmit.Text = "Save";
            }
            catch (Exception ex)
            {

            }
        }
        public void BindPage()
        {
            try
            {
                DataSet ds = new DataSet();
                ds = null;
                ds = (DataSet)objBusinessLogic.GetCareerCategoryDetails();


                if (ds.Tables[0].Rows.Count == 0)
                {
                    //Bind your grid here
                    lblempty.Visible = true;
                    dgCareer.Visible = false;

                }
                else
                {
                    lblempty.Visible = false;
                    dgCareer.Visible = true;
                    dgCareer.DataSource = ds;
                    dgCareer.DataBind();
                }
                
            }
            catch (Exception ex)
            {

            }
        }
        protected void dgCareer_PageIndexChanging(object source, DataGridPageChangedEventArgs e)
        {
            dgCareer.CurrentPageIndex = e.NewPageIndex;
            this.BindPage();
        }
    }
}