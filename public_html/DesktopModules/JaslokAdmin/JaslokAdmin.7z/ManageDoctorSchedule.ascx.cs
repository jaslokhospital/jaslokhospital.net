﻿using BusinessDataLayer;
using DotNetNuke.Entities.Modules;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DesktopModules_JaslokAdmin_ManageDoctorSchedule : PortalModuleBase
{
    public BusinessLogic objBusinessLogic = new BusinessLogic();
    public DataAccessLogic objDALogic = new DataAccessLogic();
    public DataAccessEntities objDAEntities = new DataAccessEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bindDoctor();
            BindPage();
            ViewState["DSId"] = 0;
            ViewState["Action"] = "INSERT";
        }

    }

    private void BindPage()
     {
        try
        {
            DataSet ds = new DataSet();
            ds = null;
            ds = (DataSet)objBusinessLogic.GetDoctorScheduleDetails();

            dgscgrid.DataSource = ds;
            dgscgrid.DataBind();
        }
        catch (Exception ex)
        {

        }
    }
    protected void drpDoctorNM_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        ds = null;

        int SelectedDid = Int32.Parse(drpDoctorName.SelectedValue);
        objDAEntities.DoctorId = Convert.ToInt32(drpDoctorName.SelectedValue);
       
        ds = (DataSet)objBusinessLogic.GetDoctorSchedule(objDAEntities);
       
        dgscgrid.DataSource = ds;
        dgscgrid.DataBind();



    }
    private void bindDoctor()
    {
        DataSet ds = new DataSet();
        ds = null;
      
        objDAEntities.DoctorId = Convert.ToInt32(drpDoctorName.SelectedValue);
        ds = (DataSet)objBusinessLogic.GetDoctorById(objDAEntities);
        drpDoctorName.DataValueField = "DoctorId";
        drpDoctorName.DataTextField = "Name";

        drpDoctorName.DataSource = ds;
        drpDoctorName.DataBind();
        drpDoctorName.Items.Insert(0, new ListItem("-Select-", "0"));
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = new DataSet();
            ds = null;
          
            objDAEntities.DoctorId = Convert.ToInt32(drpDoctorName.SelectedValue);
            objDAEntities.Day = txtDay.Text;
            objDAEntities.Time = txtTime.Text;
            objDAEntities.Room = txtRoom.Text;
            objDAEntities.Action = ViewState["Action"].ToString();
            lblMessage.Visible = true;
            if (ViewState["Action"].ToString() == "INSERT")
            {
                ds = (DataSet)objBusinessLogic.DSInsertUpdateDelete(objDAEntities);
                lblMessage.CssClass = "successlbl";
                lblMessage.Text = "Data Save successfully!!!";
            }
                ViewState["Action"] = "INSERT";
                BindPage();
                Clear();
            }
         catch (Exception ex)
        {

        }
       }

    protected void OnRowEditing(object sender, GridViewEditEventArgs e)
    {
        dgscgrid.EditIndex = e.NewEditIndex;

        this.BindPage();
    }

    protected void OnRowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataSet ds = new DataSet();
        ds = null;
        GridViewRow row = dgscgrid.Rows[e.RowIndex];
        int DSId = Convert.ToInt32(dgscgrid.DataKeys[e.RowIndex].Values[0]);
        string Day = (row.FindControl("txtDay") as TextBox).Text;
        string Time = (row.FindControl("txtTime") as TextBox).Text;
        string Room = (row.FindControl("txtRoom") as TextBox).Text;
       
        objDAEntities.DSId = DSId;
        objDAEntities.DoctorId = Convert.ToInt32(drpDoctorName.SelectedValue);

        objDAEntities.Day = Day;
        objDAEntities.Time = Time;
        objDAEntities.Room = Room;
        ViewState["Action"] = "UPDATE";
        if (ViewState["Action"].ToString() == "UPDATE")
        {
            objDAEntities.Action = "UPDATE";
            lblMessage.Visible = true;
            ds = (DataSet)objBusinessLogic.DSInsertUpdateDelete(objDAEntities);
            lblMessage.CssClass = "successlbl";
            lblMessage.Text = "Data update successfully!!!";
        }
        dgscgrid.EditIndex = -1;
        this.BindPage();
    }

    protected void OnRowCancelingEdit(object sender, EventArgs e)
    {
        dgscgrid.EditIndex = -1;
        this.BindPage();
    }

    protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataSet ds = new DataSet();
        ds = null;
        int DSId = Convert.ToInt32(dgscgrid.DataKeys[e.RowIndex].Values[0]);
        objDAEntities.DSId = DSId;
        ViewState["Action"] = "DELETE";
        if (ViewState["Action"].ToString() == "DELETE")
        {
            objDAEntities.Action = "DELETE";
            ds = (DataSet)objBusinessLogic.DSInsertUpdateDelete(objDAEntities);
            lblMessage.Visible = true;
            lblMessage.CssClass = "successlbl";
            lblMessage.Text = "Data deleted successfully!!!";
        }
        this.BindPage();
    }

    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex != dgscgrid.EditIndex)
        //{
        //    (e.Row.Cells[2].Controls[2] as LinkButton).Attributes["onclick"] = "return confirm('Do you want to delete this row?');";
        //}
    }
    public void Clear()
    {
        drpDoctorName.ClearSelection();
        txtDay.Text = "";
        txtTime.Text = "";
        txtRoom.Text = "";
    
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        lblMessage.Visible = false;
    }
    
}

